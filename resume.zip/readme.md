# My Resume
This repo contains my resumes.

Current resume is inspired from YAAC template, Some changes are done in default template to meet the requirements

[YAAC](https://github.com/darwiin/awesome-neue-latex-cv)
